var app = require('express')();
var bodyParser = require('body-parser');
var cors = require('cors');
app.use(cors());
app.use(bodyParser.json());
let users = [];
app.post('/register',(req,res)=>{
    console.log(req.body);
    users.push(req.body);
    console.log(users);
    res.json({status:"success",message:"User Registered Successfully"});
});
app.post('/verify',(req,res)=>{
    console.log(req.body);
    let userDetails = req.body;
    let checkUser = users.filter((user)=>{
        return user.username == userDetails.username && user.password == userDetails.password;
    });
    if(checkUser.length==1)
    res.json({status:"success",message:"Welcome"+userDetails.username});
    else
    res.json({status:"failure",message:"Invalid username and password. Kindly try again or register"});
});
app.listen(7000,()=>{
    console.log("server is running on 7000");
});
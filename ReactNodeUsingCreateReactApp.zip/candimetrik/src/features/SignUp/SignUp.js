import React from 'react';
import './SignUp.css';

class SignUp extends React.Component {
  constructor(props)
  {
    super(props);
    this.state={
      username:"",
      password:"",
      email:"",
      firstname:"",
      lastname:"",
      gender:"",
      country:""
    };
    this.handleSubmit = this.handleSubmit.bind(this);
    this.updateField = this.updateField.bind(this);
  }
  
  async handleSubmit(event)
  {
    event.preventDefault();
    let result = await fetch('http://localhost:7000/register', {
      method: 'POST', // *GET, POST, PUT, DELETE, etc.
      mode: 'cors', // no-cors, cors, *same-origin
      cache: 'no-cache', // *default, no-cache, reload, force-cache, only-if-cached
      credentials: 'same-origin', // include, *same-origin, omit
      headers: {
          'Content-Type': 'application/json',
          // 'Content-Type': 'application/x-www-form-urlencoded',
      },
      redirect: 'follow', // manual, *follow, error
      referrer: 'no-referrer', // no-referrer, *client
      body: JSON.stringify(this.state), // body data type must match "Content-Type" header
  });
  let resultingJson = await result.json();
  console.log(resultingJson);
  alert(resultingJson.message);

  }

  updateField(event)
  {
    console.log(event.target.value);
    this.setState({
      [event.target.name]:event.target.value
    });
  }

  render()
  {
  return (
    <form className="col-md-6" onSubmit={this.handleSubmit}>
      <label className="row">
      Username:
      <input name="username" className="form-control" type="text" value={this.state.username} onChange={this.updateField}/>
      </label>
      <label className="row">
      Password:
      <input name="password" className="form-control" type="password" value={this.state.password}  onChange={this.updateField}/>
      </label>
      <label className="row">
      Email:
      <input name="email" className="form-control" type="text" value={this.state.email}  onChange={this.updateField}/>
      </label>
      <label className="row">
      FirstName:
      <input name="firstname" className="form-control" type="text" value={this.state.firstname}  onChange={this.updateField}/>
      </label>
      <label className="row">
      LastName:
      <input name="lastname" className="form-control" type="text" value={this.state.lastname} onChange={this.updateField}/>
      </label>
      <label>
      Gender:
      <br/>
      <input  type="radio" name="gender"  value="Male" onChange={this.updateField}/>Male
      <br/>
      <input  type="radio" name="gender"  value="Female" onChange={this.updateField}/>Female
      </label>
      <label className="row">
      Country:
      <input name="country" className="form-control" type="text" value={this.state.country} onChange={this.updateField}/>
      </label>
      <div className="row">
      <input className="form-control bg-success submit" type="submit" value="Submit"/>
      </div>
      <div className="row bottom-100">
      <input className="form-control bg-success submit" type="reset" value="Reset"/>
      </div>
    </form>
  );
  }
}

export default SignUp;

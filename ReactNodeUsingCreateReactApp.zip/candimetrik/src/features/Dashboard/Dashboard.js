import React from 'react';
import './Dashboard.css';

function Dashboard() {
  return (
    <div className="App">
      Dashboard
    </div>
  );
}

export default Dashboard;

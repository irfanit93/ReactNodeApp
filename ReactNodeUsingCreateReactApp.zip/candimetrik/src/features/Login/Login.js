import React from 'react';
import './Login.css';

class Login extends React.Component {
  constructor(props)
  {
    super(props);
    this.state = {
      username:"",
      password:""
    };
    this.handleSubmit = this.handleSubmit.bind(this);
    this.updateField = this.updateField.bind(this);
  }
  async handleSubmit(event)
  {
    event.preventDefault();
    let result = await fetch('http://localhost:7000/verify', {
      method: 'POST', // *GET, POST, PUT, DELETE, etc.
      mode: 'cors', // no-cors, cors, *same-origin
      cache: 'no-cache', // *default, no-cache, reload, force-cache, only-if-cached
      credentials: 'same-origin', // include, *same-origin, omit
      headers: {
          'Content-Type': 'application/json',
          // 'Content-Type': 'application/x-www-form-urlencoded',
      },
      redirect: 'follow', // manual, *follow, error
      referrer: 'no-referrer', // no-referrer, *client
      body: JSON.stringify(this.state), // body data type must match "Content-Type" header
  });
  let resultingJson = await result.json();
  console.log(resultingJson);
  alert(resultingJson.message);

  }

  updateField(event)
  {
    console.log(event.target.value);
    this.setState({
      [event.target.name]:event.target.value
    });
  }

  render()
  {
  return (
    <form className="col-md-6"  onSubmit={this.handleSubmit}>
      <label className="row">
      Username:
      <input className="form-control" name="username" type="text" value={this.state.username} onChange={this.updateField}/>
      </label>
      <label className="row">
      Password:
      <input className="form-control" name="password" type="password" value={this.state.password} onChange={this.updateField}/>
      </label>
      <div className="row">
      <input className="form-control bg-success submit" type="submit" value="Submit"/>
      </div>
    </form>
  );
  }
}

export default Login;

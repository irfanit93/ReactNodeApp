import React from 'react';
import { BrowserRouter as Router, Route, Link } from "react-router-dom";
import Login from './features/Login/Login';
import SignUp from './features/SignUp/SignUp';/* 
import Dashboard from './features/Dashboard/Dashboard'; */
import './App.css';

function App({ title }) {
  return (
    <div className="container-fluid no-padding">
      <header className="col-md-12 text-center no-padding">
        <h1 className="jumbotron">{title}</h1>
      </header>
      <div className="col-md-12">
      <Router>
          <nav className="col-md-offset-4 col-md-4">
            <ul className="col-md-12 text-center no-list-style nav nav-tabs" id="myTab" role="tablist">
              <li className="nav-item active">
                <Link className="nav-link" id="home-tab"  role="tab" aria-controls="home" aria-selected="true" to="/login/">Login</Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link" id="profile-tab"  role="tab" aria-controls="profile" aria-selected="false" to="/signup/">SignUp</Link>
              </li>
            </ul>
          </nav>
          <div className="col-md-offset-2 col-md-8 top-20">
              <Route path="/login/" component={Login} />
              <Route path="/signup/" component={SignUp} />
              </div>
      </Router>
      </div>
    </div>
  );
}

export default App;
